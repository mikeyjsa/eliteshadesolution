var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/[externals]__1eyk779jd_av4._.js")
R.c("server/chunks/[root-of-the-server]__05bmej_qbrf1s._.js")
R.m(62395)
module.exports=R.m(62395).exports
