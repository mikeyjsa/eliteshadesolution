var R=require("../../chunks/[turbopack]_runtime.js")("server/app/twitter-image/route.js")
R.c("server/chunks/[root-of-the-server]__1ra0syy58npmm._.js")
R.c("server/chunks/_1ta3kpgeu6g2v._.js")
R.c("server/chunks/[root-of-the-server]__0jbtwdzw7x7ja._.js")
R.c("server/chunks/_08y5qpmrxcjig._.js")
R.c("server/chunks/_next-internal_server_app_twitter-image_route_actions_0i8kas83hx149.js")
R.m(91433)
module.exports=R.m(91433).exports
