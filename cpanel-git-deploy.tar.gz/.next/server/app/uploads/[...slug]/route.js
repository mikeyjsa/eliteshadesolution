var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/uploads/[...slug]/route.js")
R.c("server/chunks/[externals]__183jtjwqmd5yp._.js")
R.c("server/chunks/_1t1-t2gf0ww9k._.js")
R.c("server/chunks/_14ra4y59-ljyy._.js")
R.c("server/chunks/[root-of-the-server]__0jbtwdzw7x7ja._.js")
R.c("server/chunks/lib_0wp3qwv28m0y5._.js")
R.c("server/chunks/_next-internal_server_app_uploads_[___slug]_route_actions_0q98pg1zcw6ad.js")
R.m(70399)
module.exports=R.m(70399).exports
