(()=>{var a={};a.id=985,a.ids=[985],a.modules={261:a=>{"use strict";a.exports=require("next/dist/shared/lib/router/utils/app-paths")},3295:a=>{"use strict";a.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:a=>{"use strict";a.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},14985:a=>{"use strict";a.exports=require("dns")},15790:(a,b,c)=>{"use strict";c.d(b,{GP:()=>n,Hi:()=>e,OI:()=>j,W6:()=>i,_2:()=>p,b2:()=>f,c9:()=>m,i7:()=>l,vv:()=>o,yy:()=>d});let d="Elite Shade Solutions",e="Engineered Shade. Exceptional Spaces.",f="Premium Kalahari shade sails, professionally installed in Cape Town. Get a real online estimate in two minutes with transparent pricing, engineered fixings, and owner-led service.",g="https://eliteshadesolutions.co.za",h=new Set(["0.0.0.0","127.0.0.1","localhost","::1"]),i=function(a){try{let b=new URL(a?.trim()||g),c=b.hostname.toLowerCase();if(!/^https?:$/.test(b.protocol)||h.has(c)||"www.eliteshadesolutions.co.za"===c)return g;return b.origin}catch{return g}}(process.env.NEXT_PUBLIC_SITE_URL);function j(a="/"){return new URL(a,i).toString()}function k(a){return a?.trim().toLowerCase()||""}function l(a){var b;let c=(a.users||[]).filter(a=>a.active&&!1!==a.receive_admin_notifications).map(a=>k(a.email)).filter(Boolean);return Array.from(new Set([...Array.from(new Set([k((b=a.settings).info_email),...(b.notification_emails||"").split(/[\n,;]/).map(a=>k(a)).filter(Boolean)])).filter(Boolean),...c])).filter(Boolean)}function m(a){return a.eft_details?.trim()||"Bank: FNB\nAccount name: Elite Shade Solutions\nAccount number: 630 123 4567\nBranch code: 250 655"}function n(a){return"payfast_and_eft"==("eft_only"===a.payment_mode?"eft_only":"payfast_and_eft")}function o(a){return n(a)?"PayFast or EFT":"EFT"}function p(a){return n(a)?"PayFast card payment or direct EFT":"direct EFT"}},19121:a=>{"use strict";a.exports=require("next/dist/server/app-render/action-async-storage.external.js")},21820:a=>{"use strict";a.exports=require("os")},27910:a=>{"use strict";a.exports=require("stream")},28354:a=>{"use strict";a.exports=require("util")},29021:a=>{"use strict";a.exports=require("fs")},29294:a=>{"use strict";a.exports=require("next/dist/server/app-render/work-async-storage.external.js")},30787:(a,b,c)=>{"use strict";Object.defineProperty(b,"__esModule",{value:!0}),Object.defineProperty(b,"createDedupedByCallsiteServerErrorLoggerDev",{enumerable:!0,get:function(){return i}});let d=function(a,b){if(a&&a.__esModule)return a;if(null===a||"object"!=typeof a&&"function"!=typeof a)return{default:a};var c=e(b);if(c&&c.has(a))return c.get(a);var d={__proto__:null},f=Object.defineProperty&&Object.getOwnPropertyDescriptor;for(var g in a)if("default"!==g&&Object.prototype.hasOwnProperty.call(a,g)){var h=f?Object.getOwnPropertyDescriptor(a,g):null;h&&(h.get||h.set)?Object.defineProperty(d,g,h):d[g]=a[g]}return d.default=a,c&&c.set(a,d),d}(c(74515));function e(a){if("function"!=typeof WeakMap)return null;var b=new WeakMap,c=new WeakMap;return(e=function(a){return a?c:b})(a)}let f={current:null},g="function"==typeof d.cache?d.cache:a=>a,h=console.warn;function i(a){return function(...b){h(a(...b))}}g(a=>{try{h(f.current)}finally{f.current=null}})},33873:a=>{"use strict";a.exports=require("path")},34631:a=>{"use strict";a.exports=require("tls")},44870:a=>{"use strict";a.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},48975:(a,b,c)=>{"use strict";c.r(b),c.d(b,{handler:()=>H,patchFetch:()=>G,routeModule:()=>C,serverHooks:()=>F,workAsyncStorage:()=>D,workUnitAsyncStorage:()=>E});var d={};c.r(d),c.d(d,{POST:()=>B});var e=c(95736),f=c(9117),g=c(4044),h=c(39326),i=c(32324),j=c(261),k=c(54290),l=c(85328),m=c(38928),n=c(46595),o=c(3421),p=c(17679),q=c(41681),r=c(63446),s=c(86439),t=c(51356),u=c(10641),v=c(3578),w=c(81929),x=c(66147),y=c(87078),z=c(52477),A=c(15790);async function B(a){let{quoteId:b,date:c,installer:d,teamId:e}=await a.json(),f=new Date().toISOString(),g=await (0,x.Ny)(),h=g?.name??"owner",i=g?.id??"system",j=await (0,v.Tk)(a=>{let g=a.quotes.find(a=>a.id===b);if(g&&("scheduled"===g.status||"installed"===g.status))return null;let j="string"==typeof e?a.teams.find(a=>a.id===e&&a.active):null,k=j?.name||d||"Crew A",l=g?a.customers.find(a=>a.id===g.customer_id):null,m=a.installations.find(a=>a.quote_id===b);return m?(m.scheduled_date=c,m.installer=k||m.installer,m.team_id=j?.id??m.team_id??null):a.installations.unshift({id:(0,v.Ld)("ins_"),quote_id:b,scheduled_date:c,installer:k,team_id:j?.id??null,status:"pending",notes:""}),g&&("deposit_paid"===g.status||"confirmed"===g.status)&&(g.status="scheduled",g.updated_at=f),a.activities.unshift({id:(0,v.Ld)("act_"),quote_id:b,user:h,user_id:i,type:"schedule",message:`Installation scheduled for ${(0,y.yO)(c)} (${k}).`,created_at:f}),(0,z.j)(a,{title:`Job scheduled — ${l?.name??"Customer"}`,message:`Scheduled for ${(0,y.yO)(c)} and assigned to ${k}.`,href:`/admin/quotes/${b}`,kind:"schedule",quote_id:b,created_at:f}),a.installations.find(a=>a.quote_id===b)});if(!j)return u.NextResponse.json({error:"This lead is already locked for scheduling changes"},{status:400});let k=await (0,v.xA)(),l=k.quotes.find(a=>a.id===b),m=l&&k.customers.find(a=>a.id===l.customer_id),n=j.team_id?k.teams.find(a=>a.id===j.team_id):k.teams.find(a=>a.name===j.installer),o=(0,A.i7)({settings:k.settings,users:k.users});if(m){let a=k.settings.email_templates.scheduled;for(let e of(await (0,w.ZM)(m.email,a.subject,(0,w.XX)(a.body,{name:m.name,date:(0,y.yO)(c)})),o))await (0,w.ZM)(e,`Installation booked — ${m.name}`,`Installation has been scheduled in the admin.

Client: ${m.name}
Date: ${(0,y.yO)(c)}
Installer: ${n?.name||d||j.installer||"Crew A"}
Quote ID: ${b}
CRM: ${(0,A.OI)(`/admin/quotes/${b}`)}`);n?.email&&await (0,w.ZM)(n.email,`New job assigned — ${m.name}`,`A job has been assigned to ${n.name}.

Client: ${m.name}
Date: ${(0,y.yO)(c)}
Suburb: ${m.suburb||"—"}
Phone: ${m.phone||"—"}
Email: ${m.email}
CRM: ${(0,A.OI)(`/admin/quotes/${b}`)}`)}return u.NextResponse.json({ok:!0,installation:j})}let C=new e.AppRouteRouteModule({definition:{kind:f.RouteKind.APP_ROUTE,page:"/api/schedule/route",pathname:"/api/schedule",filename:"route",bundlePath:"app/api/schedule/route"},distDir:".next",relativeProjectDir:"",resolvedPagePath:"/Users/macbookprom5/Claude/Projects/Elite Shade Solutions (1)/elite-shade/app/api/schedule/route.ts",nextConfigOutput:"standalone",userland:d}),{workAsyncStorage:D,workUnitAsyncStorage:E,serverHooks:F}=C;function G(){return(0,g.patchFetch)({workAsyncStorage:D,workUnitAsyncStorage:E})}async function H(a,b,c){var d;let e="/api/schedule/route";"/index"===e&&(e="/");let g=await C.prepare(a,b,{srcPage:e,multiZoneDraftMode:!1});if(!g)return b.statusCode=400,b.end("Bad Request"),null==c.waitUntil||c.waitUntil.call(c,Promise.resolve()),null;let{buildId:u,params:v,nextConfig:w,isDraftMode:x,prerenderManifest:y,routerServerContext:z,isOnDemandRevalidate:A,revalidateOnlyGenerated:B,resolvedPathname:D}=g,E=(0,j.normalizeAppPath)(e),F=!!(y.dynamicRoutes[E]||y.routes[D]);if(F&&!x){let a=!!y.routes[D],b=y.dynamicRoutes[E];if(b&&!1===b.fallback&&!a)throw new s.NoFallbackError}let G=null;!F||C.isDev||x||(G="/index"===(G=D)?"/":G);let H=!0===C.isDev||!F,I=F&&!H,J=a.method||"GET",K=(0,i.getTracer)(),L=K.getActiveScopeSpan(),M={params:v,prerenderManifest:y,renderOpts:{experimental:{cacheComponents:!!w.experimental.cacheComponents,authInterrupts:!!w.experimental.authInterrupts},supportsDynamicResponse:H,incrementalCache:(0,h.getRequestMeta)(a,"incrementalCache"),cacheLifeProfiles:null==(d=w.experimental)?void 0:d.cacheLife,isRevalidate:I,waitUntil:c.waitUntil,onClose:a=>{b.on("close",a)},onAfterTaskError:void 0,onInstrumentationRequestError:(b,c,d)=>C.onRequestError(a,b,d,z)},sharedContext:{buildId:u}},N=new k.NodeNextRequest(a),O=new k.NodeNextResponse(b),P=l.NextRequestAdapter.fromNodeNextRequest(N,(0,l.signalFromNodeResponse)(b));try{let d=async c=>C.handle(P,M).finally(()=>{if(!c)return;c.setAttributes({"http.status_code":b.statusCode,"next.rsc":!1});let d=K.getRootSpanAttributes();if(!d)return;if(d.get("next.span_type")!==m.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${d.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let e=d.get("next.route");if(e){let a=`${J} ${e}`;c.setAttributes({"next.route":e,"http.route":e,"next.span_name":a}),c.updateName(a)}else c.updateName(`${J} ${a.url}`)}),g=async g=>{var i,j;let k=async({previousCacheEntry:f})=>{try{if(!(0,h.getRequestMeta)(a,"minimalMode")&&A&&B&&!f)return b.statusCode=404,b.setHeader("x-nextjs-cache","REVALIDATED"),b.end("This page could not be found"),null;let e=await d(g);a.fetchMetrics=M.renderOpts.fetchMetrics;let i=M.renderOpts.pendingWaitUntil;i&&c.waitUntil&&(c.waitUntil(i),i=void 0);let j=M.renderOpts.collectedTags;if(!F)return await (0,o.I)(N,O,e,M.renderOpts.pendingWaitUntil),null;{let a=await e.blob(),b=(0,p.toNodeOutgoingHttpHeaders)(e.headers);j&&(b[r.NEXT_CACHE_TAGS_HEADER]=j),!b["content-type"]&&a.type&&(b["content-type"]=a.type);let c=void 0!==M.renderOpts.collectedRevalidate&&!(M.renderOpts.collectedRevalidate>=r.INFINITE_CACHE)&&M.renderOpts.collectedRevalidate,d=void 0===M.renderOpts.collectedExpire||M.renderOpts.collectedExpire>=r.INFINITE_CACHE?void 0:M.renderOpts.collectedExpire;return{value:{kind:t.CachedRouteKind.APP_ROUTE,status:e.status,body:Buffer.from(await a.arrayBuffer()),headers:b},cacheControl:{revalidate:c,expire:d}}}}catch(b){throw(null==f?void 0:f.isStale)&&await C.onRequestError(a,b,{routerKind:"App Router",routePath:e,routeType:"route",revalidateReason:(0,n.c)({isRevalidate:I,isOnDemandRevalidate:A})},z),b}},l=await C.handleResponse({req:a,nextConfig:w,cacheKey:G,routeKind:f.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:y,isRoutePPREnabled:!1,isOnDemandRevalidate:A,revalidateOnlyGenerated:B,responseGenerator:k,waitUntil:c.waitUntil});if(!F)return null;if((null==l||null==(i=l.value)?void 0:i.kind)!==t.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==l||null==(j=l.value)?void 0:j.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});(0,h.getRequestMeta)(a,"minimalMode")||b.setHeader("x-nextjs-cache",A?"REVALIDATED":l.isMiss?"MISS":l.isStale?"STALE":"HIT"),x&&b.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let m=(0,p.fromNodeOutgoingHttpHeaders)(l.value.headers);return(0,h.getRequestMeta)(a,"minimalMode")&&F||m.delete(r.NEXT_CACHE_TAGS_HEADER),!l.cacheControl||b.getHeader("Cache-Control")||m.get("Cache-Control")||m.set("Cache-Control",(0,q.getCacheControlHeader)(l.cacheControl)),await (0,o.I)(N,O,new Response(l.value.body,{headers:m,status:l.value.status||200})),null};L?await g(L):await K.withPropagatedContext(a.headers,()=>K.trace(m.BaseServerSpan.handleRequest,{spanName:`${J} ${a.url}`,kind:i.SpanKind.SERVER,attributes:{"http.method":J,"http.target":a.url}},g))}catch(b){if(b instanceof s.NoFallbackError||await C.onRequestError(a,b,{routerKind:"App Router",routePath:E,routeType:"route",revalidateReason:(0,n.c)({isRevalidate:I,isOnDemandRevalidate:A})}),F)throw b;return await (0,o.I)(N,O,new Response(null,{status:500})),null}}},52477:(a,b,c)=>{"use strict";c.d(b,{j:()=>e});var d=c(3578);function e(a,b){let c={id:(0,d.Ld)("ntf_"),title:b.title,message:b.message,href:b.href,kind:b.kind,quote_id:b.quote_id,read_at:b.read_at??null,created_at:b.created_at??new Date().toISOString()};return a.notifications.unshift(c),a.notifications=a.notifications.slice(0,250),c}},55511:a=>{"use strict";a.exports=require("crypto")},55591:a=>{"use strict";a.exports=require("https")},63033:a=>{"use strict";a.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},66147:(a,b,c)=>{"use strict";c.d(b,{Hr:()=>h,Ny:()=>j,a$:()=>i,c7:()=>k,dj:()=>g,j_:()=>f});var d=c(86802),e=c(3578);let f="es_admin",g="es_uid";async function h(a,b){let c=await (0,e.xA)(),d=c.users.find(b=>b.email.toLowerCase()===a.toLowerCase()&&b.active);return d&&d.password===b?d:b===c.settings.admin_password?c.users[0]??null:null}async function i(){let a=await (0,d.UL)(),b=a.get(f)?.value;return!!b&&(await (0,e.xA)()).users.some(a=>a.active&&k(a.id,a.password)===b)}async function j(){let a=await (0,d.UL)(),b=a.get(f)?.value,c=a.get(g)?.value;if(!b||!c)return null;let h=(await (0,e.xA)()).users.find(a=>a.id===c&&a.active);return h&&k(h.id,h.password)===b?h:null}function k(a,b){let c=0,d="es:"+a+":"+b;for(let a=0;a<d.length;a++)c=31*c+d.charCodeAt(a)|0;return"es"+Math.abs(c).toString(36)}},74075:a=>{"use strict";a.exports=require("zlib")},78335:()=>{},79551:a=>{"use strict";a.exports=require("url")},79646:a=>{"use strict";a.exports=require("child_process")},81630:a=>{"use strict";a.exports=require("http")},81929:(a,b,c)=>{"use strict";c.d(b,{XX:()=>e,ZM:()=>i,yB:()=>j});var d=c(3578);function e(a,b){return a.replace(/\{\{(\w+)\}\}/g,(a,c)=>b[c]??"")}function f(a){return process.env[a]?.trim()||""}function g(a){let b=process.env[a]?.trim().toLowerCase();if(b)return"1"===b||"true"===b||"yes"===b||"on"===b}function h(a){let b=process.env[a]?.trim();if(!b)return;let c=Number(b);return Number.isFinite(c)?c:void 0}async function i(a,b,e,i){let j=await (0,d.xA)(),k=f("ELITE_RESEND_API_KEY")||j.settings.resend_api_key?.trim(),l=f("ELITE_EMAIL_FROM")||j.settings.email_from||"sales@eliteshadesolutions.co.za",m=j.settings.company_name||"Elite Shade Solutions",n=j.settings.sales_phone?.trim()||"",o=n&&"0676182422"!==n.replace(/\D/g,"")?n:"071 581 4268",p=function(a,b,c="Elite Shade Solutions",d="sales@eliteshadesolutions.co.za",e,f){let g=e??{salesName:"Jean-Pierre Miller",salesPhone:"071 581 4268",marketingName:"Michael Theron",marketingPhone:"060 949 1197",salesEmail:"sales@eliteshadesolutions.co.za",infoEmail:"info@eliteshadesolutions.co.za"},h=`+${g.salesPhone.replace(/\D/g,"").replace(/^0/,"27")}`,i=`+${g.marketingPhone.replace(/\D/g,"").replace(/^0/,"27")}`,j=d.trim().toLowerCase()===g.infoEmail.trim().toLowerCase(),k=j?g.marketingName:g.salesName,l=j?g.marketingPhone:g.salesPhone,m=j?i:h,n=j?g.infoEmail:g.salesEmail;return`<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>${a}</title>
<style>
  body { margin: 0 !important; padding: 0 !important; width: 100% !important; -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; }
  table, td { border-collapse: collapse; mso-table-lspace: 0; mso-table-rspace: 0; }
  img { border: 0; outline: none; text-decoration: none; -ms-interpolation-mode: bicubic; }
  @media only screen and (max-width: 620px) {
    .email-wrap { padding: 12px 0 !important; }
    .email-card { width: 100% !important; max-width: 100% !important; border-radius: 0 !important; }
    .email-pad { padding-left: 22px !important; padding-right: 22px !important; }
    .footer-stack { display: block !important; width: 100% !important; max-width: 100% !important; text-align: left !important; }
    .footer-spacer { display: none !important; width: 0 !important; height: 0 !important; }
    .footer-details { padding-top: 18px !important; }
    .footer-actions { padding-top: 14px !important; text-align: left !important; }
    .footer-button { display: block !important; text-align: center !important; }
  }
</style>
</head>
<body style="margin:0;padding:0;background:#e8ecef;font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" class="email-wrap" style="background:#e8ecef;padding:32px 16px;">
  <tr><td align="center">
    <table role="presentation" width="600" cellpadding="0" cellspacing="0" class="email-card" style="max-width:600px;width:100%;background:#ffffff;border-radius:16px;overflow:hidden;box-shadow:0 8px 32px rgba(28,39,51,0.12);">

      <!-- HEADER -->
      <tr>
        <td style="background:#1c2733;padding:28px 36px 20px;text-align:left;">
          <div style="font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;font-size:22px;font-weight:800;letter-spacing:0.08em;text-transform:uppercase;color:#ffffff;">ELITE SHADE</div>
          <div style="font-size:11px;font-weight:700;letter-spacing:0.22em;text-transform:uppercase;color:#c9a24b;margin-top:4px;">Engineered Shade. Exceptional Spaces.</div>
          <div style="height:3px;background:linear-gradient(90deg,#c9a24b,transparent);margin-top:18px;border-radius:2px;"></div>
        </td>
      </tr>

      <!-- SUBJECT BAND -->
      <tr>
        <td style="background:#283746;padding:14px 36px;">
          <p style="margin:0;font-size:16px;font-weight:700;color:#ffffff;letter-spacing:-0.01em;">${a}</p>
        </td>
      </tr>

      <!-- BODY -->
      <tr>
        <td class="email-pad" style="padding:36px 36px 28px;">
          ${b.split("\n").map(a=>a.trim()?`<p style="margin:0 0 16px;font-size:15px;line-height:1.7;color:#22303c;">${a}</p>`:"<br/>").join("")}
          ${f?`
          <table role="presentation" cellpadding="0" cellspacing="0" style="margin:8px 0 4px;">
            <tr>
              <td style="background:#c9a24b;border-radius:10px;">
                <a href="${f.url}" target="_blank" style="display:inline-block;padding:14px 30px;font-size:15px;font-weight:800;color:#1c2733;text-decoration:none;letter-spacing:0.02em;">${f.label} →</a>
              </td>
            </tr>
          </table>
          <p style="margin:10px 0 0;font-size:12px;color:#5b6b7a;">Or copy this link into your browser:<br/><a href="${f.url}" style="color:#c9a24b;word-break:break-all;">${f.url}</a></p>
          `:""}
        </td>
      </tr>

      <!-- CTA STRIP -->
      <tr>
        <td class="email-pad" style="padding:0 36px 32px;">
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#eef5ff;border-left:4px solid #1769e0;border-radius:10px;padding:0;">
            <tr>
              <td style="padding:20px 24px;">
                <p style="margin:0 0 8px;font-size:13px;font-weight:800;letter-spacing:0.06em;text-transform:uppercase;color:#1769e0;">Questions about your shade project?</p>
                <p style="margin:0;font-size:14px;color:#283746;line-height:1.65;">Reply to this email or call <a href="tel:${m}" style="color:#1769e0;text-decoration:none;font-weight:800;">${k} on ${l}</a>. We are ready to help with measurements, materials, quotes and installation planning.</p>
              </td>
            </tr>
          </table>
        </td>
      </tr>

      <!-- FOOTER -->
      <tr>
        <td class="email-pad" style="background:#10213d;padding:28px 36px 22px;">
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
            <tr>
              <td class="footer-stack" width="185" valign="top" style="width:185px;">
                <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:10px;">
                  <tr>
                    <td style="padding:14px 12px;">
                      <a href="https://eliteshadesolutions.co.za" target="_blank" style="text-decoration:none;">
                        <img src="https://eliteshadesolutions.co.za/_next/image?url=%2Flogo.png&amp;w=640&amp;q=75" width="160" alt="Elite Shade Solutions" style="display:block;width:160px;max-width:100%;height:auto;" />
                      </a>
                    </td>
                  </tr>
                </table>
              </td>
              <td class="footer-spacer" width="22" style="width:22px;">&nbsp;</td>
              <td class="footer-stack footer-details" valign="top" style="font-size:12px;color:#b9c7d8;line-height:1.7;">
                <strong style="font-size:14px;color:#ffffff;">${c}</strong><br/>
                <span style="color:#67a8ff;font-size:10px;font-weight:800;letter-spacing:0.1em;text-transform:uppercase;">Engineered shade. Exceptional spaces.</span><br/>
                Cape Town, Western Cape
              </td>
            </tr>
          </table>
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin-top:20px;border-top:1px solid #31435d;">
            <tr>
              <td class="footer-stack" valign="top" style="padding-top:17px;font-size:11px;color:#b9c7d8;line-height:1.8;">
                <strong style="color:#ffffff;">${k}</strong> \xb7 ${j?"Marketing / Online Sales":"Sales"}<br/>
                <a href="tel:${m}" style="color:#ffffff;text-decoration:none;font-weight:700;">${l}</a><br/>
                <a href="mailto:${n}" style="color:#67a8ff;text-decoration:none;">${n}</a>
              </td>
              <td class="footer-stack footer-actions" align="right" valign="top" style="padding-top:17px;font-size:11px;line-height:1.8;">
                <a href="https://eliteshadesolutions.co.za" target="_blank" style="color:#67a8ff;text-decoration:none;">eliteshadesolutions.co.za</a><br/>
                <a href="https://eliteshadesolutions.co.za/quote" target="_blank" class="footer-button" style="display:inline-block;margin-top:6px;padding:8px 13px;background:#1769e0;border-radius:6px;color:#ffffff;text-decoration:none;font-weight:800;">Get an instant estimate →</a>
              </td>
            </tr>
          </table>
          <p style="margin:20px 0 0;padding-top:14px;border-top:1px solid #31435d;font-size:9px;line-height:1.55;color:#71839a;">This message was sent by Elite Shade Solutions regarding an enquiry, quote, invoice or project update. If it reached you in error, please reply and let us know.</p>
        </td>
      </tr>

    </table>
  </td></tr>
</table>
</body>
</html>`}(b,e,m,l,{salesName:j.settings.sales_name||"Jean-Pierre Miller",salesPhone:o,marketingName:j.settings.marketing_name||"Michael Theron",marketingPhone:j.settings.marketing_phone||"060 949 1197",salesEmail:j.settings.sales_email||l,infoEmail:j.settings.info_email||"info@eliteshadesolutions.co.za"},i),q=f("ELITE_SMTP_HOST")||j.settings.smtp_host||"",r=h("ELITE_SMTP_PORT")||j.settings.smtp_port||587,s=f("ELITE_SMTP_USER")||j.settings.smtp_user||"",t=f("ELITE_SMTP_PASS")||j.settings.smtp_pass||"",u=g("ELITE_SMTP_SECURE")??!!j.settings.smtp_secure,v=f("ELITE_EMAIL_PROVIDER"),w="smtp"===v||"resend"===v||"outbox"===v?v:j.settings.email_provider||(k?"resend":"outbox"),x="outbox",y="queued";if("smtp"===w&&q&&s)try{let d=(await c.e(5112).then(c.t.bind(c,52731,19))).createTransport({host:q,port:r,secure:u,auth:{user:s,pass:t}});await d.sendMail({from:`${m} <${l}>`,to:a,subject:b,text:e,html:p}),x="smtp",y="sent"}catch{x="smtp",y="failed"}else if("resend"===w&&k)try{let c=await fetch("https://api.resend.com/emails",{method:"POST",headers:{Authorization:`Bearer ${k}`,"Content-Type":"application/json"},body:JSON.stringify({from:`${m} <${l}>`,to:a,subject:b,text:e,html:p})});x="resend",y=c.ok?"sent":"failed"}catch{x="resend",y="failed"}return(0,d.Tk)(c=>{let f={id:(0,d.Ld)("eml_"),to:a,subject:b,body:e,html:p,sent_at:new Date().toISOString(),channel:x,status:y};return c.emails.unshift(f),f})}async function j(a,b,e,i={}){let k=await (0,d.xA)(),l=f("ELITE_RESEND_API_KEY")||k.settings.resend_api_key?.trim(),m=i.from?.trim()||"sales@eliteshadesolutions.co.za",n=i.replyTo?.trim()||m,o=k.settings.company_name||"Elite Shade Solutions",p=f("ELITE_SMTP_HOST")||k.settings.smtp_host||"",q=h("ELITE_SMTP_PORT")||k.settings.smtp_port||587,r=f("ELITE_SMTP_USER")||k.settings.smtp_user||"",s=f("ELITE_SMTP_PASS")||k.settings.smtp_pass||"",t=g("ELITE_SMTP_SECURE")??!!k.settings.smtp_secure,u=f("ELITE_EMAIL_PROVIDER"),v="smtp"===u||"resend"===u||"outbox"===u?u:k.settings.email_provider||(l?"resend":"outbox"),w=e.replace(/<style[\s\S]*?<\/style>/gi," ").replace(/<script[\s\S]*?<\/script>/gi," ").replace(/<[^>]+>/g," ").replace(/&nbsp;/gi," ").replace(/&amp;/gi,"&").replace(/\s+/g," ").trim(),x="outbox",y="queued",z="";if("smtp"===v&&p&&r)try{let d=(await c.e(5112).then(c.t.bind(c,52731,19))).createTransport({host:p,port:q,secure:t,auth:{user:r,pass:s}});await d.sendMail({from:`${o} <${m}>`,replyTo:n,to:a,subject:b,text:w,html:e}),x="smtp",y="sent"}catch(a){x="smtp",y="failed",z=a instanceof Error?a.message:"SMTP delivery failed"}else if("resend"===v&&l)try{let c=await fetch("https://api.resend.com/emails",{method:"POST",headers:{Authorization:`Bearer ${l}`,"Content-Type":"application/json"},body:JSON.stringify({from:`${o} <${m}>`,reply_to:n,to:a,subject:b,text:w,html:e})});x="resend",y=c.ok?"sent":"failed",c.ok||(z=`Email provider returned ${c.status}`)}catch(a){x="resend",y="failed",z=a instanceof Error?a.message:"Email delivery failed"}return(0,d.Tk)(c=>{let f={id:(0,d.Ld)("eml_"),to:a,subject:b,body:w,html:e,sent_at:new Date().toISOString(),channel:x,status:y,...z?{error:z}:{}};return c.emails.unshift(f),f})}},86439:a=>{"use strict";a.exports=require("next/dist/shared/lib/no-fallback-error.external")},87078:(a,b,c)=>{"use strict";function d(a){return"R "+Math.round(a).toLocaleString("en-ZA")}function e(a){return new Date(a).toLocaleDateString("en-ZA",{day:"2-digit",month:"short",year:"numeric"})}c.d(b,{eR:()=>d,yO:()=>e})},91645:a=>{"use strict";a.exports=require("net")},94735:a=>{"use strict";a.exports=require("events")},96487:()=>{}};var b=require("../../../webpack-runtime.js");b.C(a);var c=b.X(0,[1331,1692,6802,3578],()=>b(b.s=48975));module.exports=c})();