var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/users/me/route.js")
R.c("server/chunks/[externals]__183jtjwqmd5yp._.js")
R.c("server/chunks/_1v6ft7yzsyp2y._.js")
R.c("server/chunks/[root-of-the-server]__0jbtwdzw7x7ja._.js")
R.c("server/chunks/_14ra4y59-ljyy._.js")
R.c("server/chunks/lib_0pkmghakj58kf._.js")
R.c("server/chunks/_next-internal_server_app_api_users_me_route_actions_06v51f-rv9lzi.js")
R.m(57190)
module.exports=R.m(57190).exports
