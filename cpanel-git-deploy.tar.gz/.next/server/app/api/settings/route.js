var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/settings/route.js")
R.c("server/chunks/[externals]__183jtjwqmd5yp._.js")
R.c("server/chunks/_0_5345mmipfwl._.js")
R.c("server/chunks/[root-of-the-server]__0jbtwdzw7x7ja._.js")
R.c("server/chunks/_14ra4y59-ljyy._.js")
R.c("server/chunks/lib_0pkmghakj58kf._.js")
R.c("server/chunks/_next-internal_server_app_api_settings_route_actions_1bpm9acuq1z18.js")
R.m(83579)
module.exports=R.m(83579).exports
