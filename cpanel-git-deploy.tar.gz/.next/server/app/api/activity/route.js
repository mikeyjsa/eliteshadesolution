var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/activity/route.js")
R.c("server/chunks/[externals]__183jtjwqmd5yp._.js")
R.c("server/chunks/_1oslu6zw9lrcl._.js")
R.c("server/chunks/[root-of-the-server]__0jbtwdzw7x7ja._.js")
R.c("server/chunks/_14ra4y59-ljyy._.js")
R.c("server/chunks/lib_0pkmghakj58kf._.js")
R.c("server/chunks/_next-internal_server_app_api_activity_route_actions_20tc28b2f6hkh.js")
R.m(26677)
module.exports=R.m(26677).exports
