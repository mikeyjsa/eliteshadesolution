var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/leads/archive/route.js")
R.c("server/chunks/[externals]__183jtjwqmd5yp._.js")
R.c("server/chunks/_0231s1nhr457t._.js")
R.c("server/chunks/[root-of-the-server]__0jbtwdzw7x7ja._.js")
R.c("server/chunks/_14ra4y59-ljyy._.js")
R.c("server/chunks/lib_0pkmghakj58kf._.js")
R.c("server/chunks/_next-internal_server_app_api_leads_archive_route_actions_07-0rwqav0jcx.js")
R.m(46718)
module.exports=R.m(46718).exports
