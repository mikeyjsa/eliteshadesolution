var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/invoices/route.js")
R.c("server/chunks/[root-of-the-server]__1l2vz4ppkm8jp._.js")
R.c("server/chunks/_1vfj3e8rnxsqj._.js")
R.c("server/chunks/lib_0pkmghakj58kf._.js")
R.c("server/chunks/[root-of-the-server]__0jbtwdzw7x7ja._.js")
R.c("server/chunks/_14ra4y59-ljyy._.js")
R.c("server/chunks/_next-internal_server_app_api_invoices_route_actions_0oj_rscvl8-nu.js")
R.m(75275)
module.exports=R.m(75275).exports
