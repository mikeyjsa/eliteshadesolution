var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/invoices/[id]/pdf/route.js")
R.c("server/chunks/[root-of-the-server]__0i53xy0xc35z1._.js")
R.c("server/chunks/_0xggoleb7vf_7._.js")
R.c("server/chunks/_0dvgaqe2h13_8._.js")
R.c("server/chunks/[root-of-the-server]__0jbtwdzw7x7ja._.js")
R.c("server/chunks/lib_0pkmghakj58kf._.js")
R.c("server/chunks/_next-internal_server_app_api_invoices_[id]_pdf_route_actions_1h1e9g55lgc5a.js")
R.m(38384)
module.exports=R.m(38384).exports
