var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/content/route.js")
R.c("server/chunks/[externals]__183jtjwqmd5yp._.js")
R.c("server/chunks/_1hcl90-4f114g._.js")
R.c("server/chunks/[root-of-the-server]__0jbtwdzw7x7ja._.js")
R.c("server/chunks/_14ra4y59-ljyy._.js")
R.c("server/chunks/lib_0pkmghakj58kf._.js")
R.c("server/chunks/_next-internal_server_app_api_content_route_actions_1cf1ibk6n1b1u.js")
R.m(26735)
module.exports=R.m(26735).exports
