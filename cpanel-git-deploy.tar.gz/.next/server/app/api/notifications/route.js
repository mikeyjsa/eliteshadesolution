var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/notifications/route.js")
R.c("server/chunks/[externals]__183jtjwqmd5yp._.js")
R.c("server/chunks/_0q9omij-z-wif._.js")
R.c("server/chunks/[root-of-the-server]__0jbtwdzw7x7ja._.js")
R.c("server/chunks/_14ra4y59-ljyy._.js")
R.c("server/chunks/lib_0pkmghakj58kf._.js")
R.c("server/chunks/_next-internal_server_app_api_notifications_route_actions_1272ib8x7arxk.js")
R.m(56032)
module.exports=R.m(56032).exports
