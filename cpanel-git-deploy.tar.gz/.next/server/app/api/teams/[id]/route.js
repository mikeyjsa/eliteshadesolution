var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/teams/[id]/route.js")
R.c("server/chunks/[externals]__183jtjwqmd5yp._.js")
R.c("server/chunks/_02w953xy8kt4f._.js")
R.c("server/chunks/[root-of-the-server]__0jbtwdzw7x7ja._.js")
R.c("server/chunks/_14ra4y59-ljyy._.js")
R.c("server/chunks/lib_0pkmghakj58kf._.js")
R.c("server/chunks/_next-internal_server_app_api_teams_[id]_route_actions_1nm93xuig2ni6.js")
R.m(90420)
module.exports=R.m(90420).exports
