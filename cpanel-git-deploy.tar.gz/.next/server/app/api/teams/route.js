var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/teams/route.js")
R.c("server/chunks/[externals]__183jtjwqmd5yp._.js")
R.c("server/chunks/_1fm5kzfd01ggj._.js")
R.c("server/chunks/[root-of-the-server]__0jbtwdzw7x7ja._.js")
R.c("server/chunks/_14ra4y59-ljyy._.js")
R.c("server/chunks/lib_0pkmghakj58kf._.js")
R.c("server/chunks/_next-internal_server_app_api_teams_route_actions_1jor27omput86.js")
R.m(6110)
module.exports=R.m(6110).exports
