var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/route.js")
R.c("server/chunks/[root-of-the-server]__05979ziupq13v._.js")
R.c("server/chunks/_120ltgo020tsy._.js")
R.c("server/chunks/_14ra4y59-ljyy._.js")
R.c("server/chunks/[root-of-the-server]__0jbtwdzw7x7ja._.js")
R.c("server/chunks/lib_0pkmghakj58kf._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_route_actions_0vtf0y45d772a.js")
R.m(12919)
module.exports=R.m(12919).exports
