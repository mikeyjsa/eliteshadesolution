var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/payfast/itn/route.js")
R.c("server/chunks/[root-of-the-server]__1kqxij0b0ywip._.js")
R.c("server/chunks/lib_email_ts_0us6_4vov62j-._.js")
R.c("server/chunks/[root-of-the-server]__0jbtwdzw7x7ja._.js")
R.c("server/chunks/lib_0pkmghakj58kf._.js")
R.c("server/chunks/_18irpn2e39qka._.js")
R.c("server/chunks/_next-internal_server_app_api_payfast_itn_route_actions_1tv229xao5xr1.js")
R.m(61694)
module.exports=R.m(61694).exports
