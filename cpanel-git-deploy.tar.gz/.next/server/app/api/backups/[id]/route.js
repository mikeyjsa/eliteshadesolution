var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/backups/[id]/route.js")
R.c("server/chunks/[externals]__183jtjwqmd5yp._.js")
R.c("server/chunks/_11kuhyv5-huwa._.js")
R.c("server/chunks/[root-of-the-server]__0jbtwdzw7x7ja._.js")
R.c("server/chunks/_14ra4y59-ljyy._.js")
R.c("server/chunks/lib_0pkmghakj58kf._.js")
R.c("server/chunks/_next-internal_server_app_api_backups_[id]_route_actions_0-wetmksfb_r3.js")
R.m(75727)
module.exports=R.m(75727).exports
