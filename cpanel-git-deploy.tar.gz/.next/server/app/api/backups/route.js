var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/backups/route.js")
R.c("server/chunks/[externals]__183jtjwqmd5yp._.js")
R.c("server/chunks/_00yyaxqvxt7em._.js")
R.c("server/chunks/[root-of-the-server]__0jbtwdzw7x7ja._.js")
R.c("server/chunks/_14ra4y59-ljyy._.js")
R.c("server/chunks/lib_0pkmghakj58kf._.js")
R.c("server/chunks/_next-internal_server_app_api_backups_route_actions_0o5izw8vr9inj.js")
R.m(82844)
module.exports=R.m(82844).exports
