globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/ZVUWTEzgryOHMMj4KeXBn/_buildManifest.js",
    "static/ZVUWTEzgryOHMMj4KeXBn/_ssgManifest.js",
    "static/ZVUWTEzgryOHMMj4KeXBn/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/1zgmbervt4bfj.js",
    "static/chunks/0k--hvilem3xj.js",
    "static/chunks/3lbm-r_1xmrrq.js",
    "static/chunks/0pyj544q29h62.js",
    "static/chunks/turbopack-077hmtqrhcoji.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/0k--hvilem3xj.js",
        "static/chunks/3lbm-r_1xmrrq.js",
        "static/chunks/0pyj544q29h62.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/0k--hvilem3xj.js",
        "static/chunks/3lbm-r_1xmrrq.js",
        "static/chunks/0pyj544q29h62.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(site)/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/0k--hvilem3xj.js",
        "static/chunks/3lbm-r_1xmrrq.js",
        "static/chunks/0pyj544q29h62.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(site)/about/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/0k--hvilem3xj.js",
        "static/chunks/3lbm-r_1xmrrq.js",
        "static/chunks/0pyj544q29h62.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(site)/blog/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/0k--hvilem3xj.js",
        "static/chunks/3lbm-r_1xmrrq.js",
        "static/chunks/0pyj544q29h62.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(site)/blog/[slug]/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/0k--hvilem3xj.js",
        "static/chunks/3lbm-r_1xmrrq.js",
        "static/chunks/0pyj544q29h62.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(site)/contact/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/0k--hvilem3xj.js",
        "static/chunks/3lbm-r_1xmrrq.js",
        "static/chunks/0pyj544q29h62.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(site)/gallery/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/0k--hvilem3xj.js",
        "static/chunks/3lbm-r_1xmrrq.js",
        "static/chunks/0pyj544q29h62.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(site)/how-it-works/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/0k--hvilem3xj.js",
        "static/chunks/3lbm-r_1xmrrq.js",
        "static/chunks/0pyj544q29h62.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(site)/q/[token]/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/0k--hvilem3xj.js",
        "static/chunks/3lbm-r_1xmrrq.js",
        "static/chunks/0pyj544q29h62.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(site)/quote/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/0k--hvilem3xj.js",
        "static/chunks/3lbm-r_1xmrrq.js",
        "static/chunks/0pyj544q29h62.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(site)/shade-sails/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/0k--hvilem3xj.js",
        "static/chunks/3lbm-r_1xmrrq.js",
        "static/chunks/0pyj544q29h62.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/(panel)/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/0k--hvilem3xj.js",
        "static/chunks/3lbm-r_1xmrrq.js",
        "static/chunks/0pyj544q29h62.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/(panel)/backups/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/0k--hvilem3xj.js",
        "static/chunks/3lbm-r_1xmrrq.js",
        "static/chunks/0pyj544q29h62.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/(panel)/content/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/0k--hvilem3xj.js",
        "static/chunks/3lbm-r_1xmrrq.js",
        "static/chunks/0pyj544q29h62.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/(panel)/email-marketing/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/0k--hvilem3xj.js",
        "static/chunks/3lbm-r_1xmrrq.js",
        "static/chunks/0pyj544q29h62.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/(panel)/google-analytics/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/0k--hvilem3xj.js",
        "static/chunks/3lbm-r_1xmrrq.js",
        "static/chunks/0pyj544q29h62.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/(panel)/invoices/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/0k--hvilem3xj.js",
        "static/chunks/3lbm-r_1xmrrq.js",
        "static/chunks/0pyj544q29h62.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/(panel)/invoices/[id]/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/0k--hvilem3xj.js",
        "static/chunks/3lbm-r_1xmrrq.js",
        "static/chunks/0pyj544q29h62.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/(panel)/leads/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/0k--hvilem3xj.js",
        "static/chunks/3lbm-r_1xmrrq.js",
        "static/chunks/0pyj544q29h62.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/(panel)/notifications/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/0k--hvilem3xj.js",
        "static/chunks/3lbm-r_1xmrrq.js",
        "static/chunks/0pyj544q29h62.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/(panel)/pricing/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/0k--hvilem3xj.js",
        "static/chunks/3lbm-r_1xmrrq.js",
        "static/chunks/0pyj544q29h62.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/(panel)/quotes/[id]/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/0k--hvilem3xj.js",
        "static/chunks/3lbm-r_1xmrrq.js",
        "static/chunks/0pyj544q29h62.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/(panel)/reports/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/0k--hvilem3xj.js",
        "static/chunks/3lbm-r_1xmrrq.js",
        "static/chunks/0pyj544q29h62.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/(panel)/schedule/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/0k--hvilem3xj.js",
        "static/chunks/3lbm-r_1xmrrq.js",
        "static/chunks/0pyj544q29h62.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/(panel)/settings/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/0k--hvilem3xj.js",
        "static/chunks/3lbm-r_1xmrrq.js",
        "static/chunks/0pyj544q29h62.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/(panel)/teams/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/0k--hvilem3xj.js",
        "static/chunks/3lbm-r_1xmrrq.js",
        "static/chunks/0pyj544q29h62.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/(panel)/users/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/0k--hvilem3xj.js",
        "static/chunks/3lbm-r_1xmrrq.js",
        "static/chunks/0pyj544q29h62.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/login/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/0k--hvilem3xj.js",
        "static/chunks/3lbm-r_1xmrrq.js",
        "static/chunks/0pyj544q29h62.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/pay/[invoiceId]/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/0k--hvilem3xj.js",
        "static/chunks/3lbm-r_1xmrrq.js",
        "static/chunks/0pyj544q29h62.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
