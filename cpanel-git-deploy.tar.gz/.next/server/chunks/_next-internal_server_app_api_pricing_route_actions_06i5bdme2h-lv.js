module.exports=[11166,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_pricing_route_actions_06i5bdme2h-lv.js.map