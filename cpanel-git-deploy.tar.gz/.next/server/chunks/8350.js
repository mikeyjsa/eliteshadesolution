exports.id=8350,exports.ids=[8350],exports.modules={15790:(a,b,c)=>{"use strict";c.d(b,{GP:()=>n,Hi:()=>e,OI:()=>j,W6:()=>i,_2:()=>p,b2:()=>f,c9:()=>m,i7:()=>l,vv:()=>o,yy:()=>d});let d="Elite Shade Solutions",e="Engineered Shade. Exceptional Spaces.",f="Premium Kalahari shade sails, professionally installed in Cape Town. Get a real online estimate in two minutes with transparent pricing, engineered fixings, and owner-led service.",g="https://eliteshadesolutions.co.za",h=new Set(["0.0.0.0","127.0.0.1","localhost","::1"]),i=function(a){try{let b=new URL(a?.trim()||g),c=b.hostname.toLowerCase();if(!/^https?:$/.test(b.protocol)||h.has(c)||"www.eliteshadesolutions.co.za"===c)return g;return b.origin}catch{return g}}(process.env.NEXT_PUBLIC_SITE_URL);function j(a="/"){return new URL(a,i).toString()}function k(a){return a?.trim().toLowerCase()||""}function l(a){var b;let c=(a.users||[]).filter(a=>a.active&&!1!==a.receive_admin_notifications).map(a=>k(a.email)).filter(Boolean);return Array.from(new Set([...Array.from(new Set([k((b=a.settings).info_email),...(b.notification_emails||"").split(/[\n,;]/).map(a=>k(a)).filter(Boolean)])).filter(Boolean),...c])).filter(Boolean)}function m(a){return a.eft_details?.trim()||"Bank: FNB\nAccount name: Elite Shade Solutions\nAccount number: 630 123 4567\nBranch code: 250 655"}function n(a){return"payfast_and_eft"==("eft_only"===a.payment_mode?"eft_only":"payfast_and_eft")}function o(a){return n(a)?"PayFast or EFT":"EFT"}function p(a){return n(a)?"PayFast card payment or direct EFT":"direct EFT"}},39106:(a,b,c)=>{"use strict";c.d(b,{ME:()=>m,_n:()=>j,ry:()=>l,y8:()=>k});var d=c(55511),e=c(3578),f=c(81929),g=c(87078),h=c(46883),i=c(15790);async function j(a){return(0,e.Tk)(b=>{let c=b.quotes.find(b=>b.id===a);return c?(c.public_token||(c.public_token=(0,d.randomBytes)(18).toString("hex")),c.public_token):null})}function k(a){return(0,i.OI)(`/q/${a}`)}async function l(a){let b=await (0,e.xA)(),c=b.customers.find(b=>b.id===a.customer_id);if(!c||!a.public_token||null==a.final_total)return;let d=k(a.public_token),j=(0,g.eR)(a.final_total),l=(0,g.eR)(Math.round(a.final_total*b.settings.deposit_pct/100)),m=(0,i._2)(b.settings),n=(0,i.i7)({settings:b.settings,users:b.users}),o=`Hi ${c.name},

Good news — your Elite Shade quote ${(0,h.yx)(a)} is confirmed at ${j} (excl VAT).

View the full breakdown, download your quote as a PDF, and accept it online at the link below. Once you accept, we'll email your ${b.settings.deposit_pct}% deposit invoice (${l}) with secure payment options — ${m}.

Your quote is valid for 14 days. Nothing is booked until you accept, and the final scope is always confirmed at your free site survey.`;for(let b of(await (0,f.ZM)(c.email,`Your quote ${(0,h.yx)(a)} is ready — ${j}`,o,{label:"View & accept my quote",url:d}),n))await (0,f.ZM)(b,`Quote ready — ${(0,h.yx)(a)} for ${c.name}`,`Quote ${(0,h.yx)(a)} has been confirmed and emailed to ${c.email}.

Client: ${c.name}
Total: ${j}
Deposit: ${l}
View link: ${d}
CRM: ${(0,i.OI)(`/admin/quotes/${a.id}`)}`);await (0,e.Tk)(b=>{b.activities.unshift({id:(0,e.Ld)("act_"),quote_id:a.id,user:"system",user_id:"system",type:"email",message:`Quote ${(0,h.yx)(a)} emailed to ${c.email} with view/accept link.`,created_at:new Date().toISOString()})})}async function m(a,b){let c=await (0,e.xA)(),d=c.customers.find(b=>b.id===a.customer_id);if(!d)return;let j=(0,i.GP)(c.settings),k=(0,i.OI)(`/pay/${b.id}`),l=(0,i.OI)(`/api/invoices/${b.id}/pdf`),m=(0,i.c9)(c.settings),n=(0,i.i7)({settings:c.settings,users:c.users}),o=[`Hi ${d.name},`,"",`Thank you for accepting quote ${(0,h.yx)(a)}. Your ${c.settings.deposit_pct}% deposit invoice ${b.number} for ${(0,g.eR)(b.amount)} is attached below as a download link.`,"",`Download your invoice: ${l}`,"",j?"You can pay in whichever way suits you:":"Please pay by EFT to:","",...j?[`1. PayFast (card / instant EFT) — use the secure payment button below.`,"",`2. Direct EFT — pay to:`]:[],...m.split("\n"),`Reference: ${b.number}`,"","As soon as your deposit reflects, we confirm your installation date by email. If you pay by EFT, simply reply with your proof of payment to speed things up."].join("\n");for(let a of(await (0,f.ZM)(d.email,`Deposit invoice ${b.number} — secure your install date`,o,{label:j?`Pay ${(0,g.eR)(b.amount)} deposit securely`:"View payment instructions",url:k}),n))await (0,f.ZM)(a,`Deposit invoice sent — ${b.number}`,`Deposit invoice ${b.number} has been sent to ${d.email}.

Client: ${d.name}
Amount: ${(0,g.eR)(b.amount)}
Payment mode: ${j?"Gateway + EFT":"EFT only"}
Pay page: ${k}
CRM: ${(0,i.OI)(`/admin/invoices/${b.id}`)}`);await (0,e.Tk)(c=>{c.activities.unshift({id:(0,e.Ld)("act_"),quote_id:a.id,user:"system",user_id:"system",type:"email",message:`Deposit invoice ${b.number} emailed to ${d.email} with ${j?"PayFast + EFT":"EFT-only"} payment options.`,created_at:new Date().toISOString()})})}},78335:()=>{},81929:(a,b,c)=>{"use strict";c.d(b,{XX:()=>e,ZM:()=>i,yB:()=>j});var d=c(3578);function e(a,b){return a.replace(/\{\{(\w+)\}\}/g,(a,c)=>b[c]??"")}function f(a){return process.env[a]?.trim()||""}function g(a){let b=process.env[a]?.trim().toLowerCase();if(b)return"1"===b||"true"===b||"yes"===b||"on"===b}function h(a){let b=process.env[a]?.trim();if(!b)return;let c=Number(b);return Number.isFinite(c)?c:void 0}async function i(a,b,e,i){let j=await (0,d.xA)(),k=f("ELITE_RESEND_API_KEY")||j.settings.resend_api_key?.trim(),l=f("ELITE_EMAIL_FROM")||j.settings.email_from||"sales@eliteshadesolutions.co.za",m=j.settings.company_name||"Elite Shade Solutions",n=j.settings.sales_phone?.trim()||"",o=n&&"0676182422"!==n.replace(/\D/g,"")?n:"071 581 4268",p=function(a,b,c="Elite Shade Solutions",d="sales@eliteshadesolutions.co.za",e,f){let g=e??{salesName:"Jean-Pierre Miller",salesPhone:"071 581 4268",marketingName:"Michael Theron",marketingPhone:"060 949 1197",salesEmail:"sales@eliteshadesolutions.co.za",infoEmail:"info@eliteshadesolutions.co.za"},h=`+${g.salesPhone.replace(/\D/g,"").replace(/^0/,"27")}`,i=`+${g.marketingPhone.replace(/\D/g,"").replace(/^0/,"27")}`,j=d.trim().toLowerCase()===g.infoEmail.trim().toLowerCase(),k=j?g.marketingName:g.salesName,l=j?g.marketingPhone:g.salesPhone,m=j?i:h,n=j?g.infoEmail:g.salesEmail;return`<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>${a}</title>
<style>
  body { margin: 0 !important; padding: 0 !important; width: 100% !important; -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; }
  table, td { border-collapse: collapse; mso-table-lspace: 0; mso-table-rspace: 0; }
  img { border: 0; outline: none; text-decoration: none; -ms-interpolation-mode: bicubic; }
  @media only screen and (max-width: 620px) {
    .email-wrap { padding: 12px 0 !important; }
    .email-card { width: 100% !important; max-width: 100% !important; border-radius: 0 !important; }
    .email-pad { padding-left: 22px !important; padding-right: 22px !important; }
    .footer-stack { display: block !important; width: 100% !important; max-width: 100% !important; text-align: left !important; }
    .footer-spacer { display: none !important; width: 0 !important; height: 0 !important; }
    .footer-details { padding-top: 18px !important; }
    .footer-actions { padding-top: 14px !important; text-align: left !important; }
    .footer-button { display: block !important; text-align: center !important; }
  }
</style>
</head>
<body style="margin:0;padding:0;background:#e8ecef;font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" class="email-wrap" style="background:#e8ecef;padding:32px 16px;">
  <tr><td align="center">
    <table role="presentation" width="600" cellpadding="0" cellspacing="0" class="email-card" style="max-width:600px;width:100%;background:#ffffff;border-radius:16px;overflow:hidden;box-shadow:0 8px 32px rgba(28,39,51,0.12);">

      <!-- HEADER -->
      <tr>
        <td style="background:#1c2733;padding:28px 36px 20px;text-align:left;">
          <div style="font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;font-size:22px;font-weight:800;letter-spacing:0.08em;text-transform:uppercase;color:#ffffff;">ELITE SHADE</div>
          <div style="font-size:11px;font-weight:700;letter-spacing:0.22em;text-transform:uppercase;color:#c9a24b;margin-top:4px;">Engineered Shade. Exceptional Spaces.</div>
          <div style="height:3px;background:linear-gradient(90deg,#c9a24b,transparent);margin-top:18px;border-radius:2px;"></div>
        </td>
      </tr>

      <!-- SUBJECT BAND -->
      <tr>
        <td style="background:#283746;padding:14px 36px;">
          <p style="margin:0;font-size:16px;font-weight:700;color:#ffffff;letter-spacing:-0.01em;">${a}</p>
        </td>
      </tr>

      <!-- BODY -->
      <tr>
        <td class="email-pad" style="padding:36px 36px 28px;">
          ${b.split("\n").map(a=>a.trim()?`<p style="margin:0 0 16px;font-size:15px;line-height:1.7;color:#22303c;">${a}</p>`:"<br/>").join("")}
          ${f?`
          <table role="presentation" cellpadding="0" cellspacing="0" style="margin:8px 0 4px;">
            <tr>
              <td style="background:#c9a24b;border-radius:10px;">
                <a href="${f.url}" target="_blank" style="display:inline-block;padding:14px 30px;font-size:15px;font-weight:800;color:#1c2733;text-decoration:none;letter-spacing:0.02em;">${f.label} →</a>
              </td>
            </tr>
          </table>
          <p style="margin:10px 0 0;font-size:12px;color:#5b6b7a;">Or copy this link into your browser:<br/><a href="${f.url}" style="color:#c9a24b;word-break:break-all;">${f.url}</a></p>
          `:""}
        </td>
      </tr>

      <!-- CTA STRIP -->
      <tr>
        <td class="email-pad" style="padding:0 36px 32px;">
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#eef5ff;border-left:4px solid #1769e0;border-radius:10px;padding:0;">
            <tr>
              <td style="padding:20px 24px;">
                <p style="margin:0 0 8px;font-size:13px;font-weight:800;letter-spacing:0.06em;text-transform:uppercase;color:#1769e0;">Questions about your shade project?</p>
                <p style="margin:0;font-size:14px;color:#283746;line-height:1.65;">Reply to this email or call <a href="tel:${m}" style="color:#1769e0;text-decoration:none;font-weight:800;">${k} on ${l}</a>. We are ready to help with measurements, materials, quotes and installation planning.</p>
              </td>
            </tr>
          </table>
        </td>
      </tr>

      <!-- FOOTER -->
      <tr>
        <td class="email-pad" style="background:#10213d;padding:28px 36px 22px;">
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
            <tr>
              <td class="footer-stack" width="185" valign="top" style="width:185px;">
                <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:10px;">
                  <tr>
                    <td style="padding:14px 12px;">
                      <a href="https://eliteshadesolutions.co.za" target="_blank" style="text-decoration:none;">
                        <img src="https://eliteshadesolutions.co.za/_next/image?url=%2Flogo.png&amp;w=640&amp;q=75" width="160" alt="Elite Shade Solutions" style="display:block;width:160px;max-width:100%;height:auto;" />
                      </a>
                    </td>
                  </tr>
                </table>
              </td>
              <td class="footer-spacer" width="22" style="width:22px;">&nbsp;</td>
              <td class="footer-stack footer-details" valign="top" style="font-size:12px;color:#b9c7d8;line-height:1.7;">
                <strong style="font-size:14px;color:#ffffff;">${c}</strong><br/>
                <span style="color:#67a8ff;font-size:10px;font-weight:800;letter-spacing:0.1em;text-transform:uppercase;">Engineered shade. Exceptional spaces.</span><br/>
                Cape Town, Western Cape
              </td>
            </tr>
          </table>
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin-top:20px;border-top:1px solid #31435d;">
            <tr>
              <td class="footer-stack" valign="top" style="padding-top:17px;font-size:11px;color:#b9c7d8;line-height:1.8;">
                <strong style="color:#ffffff;">${k}</strong> \xb7 ${j?"Marketing / Online Sales":"Sales"}<br/>
                <a href="tel:${m}" style="color:#ffffff;text-decoration:none;font-weight:700;">${l}</a><br/>
                <a href="mailto:${n}" style="color:#67a8ff;text-decoration:none;">${n}</a>
              </td>
              <td class="footer-stack footer-actions" align="right" valign="top" style="padding-top:17px;font-size:11px;line-height:1.8;">
                <a href="https://eliteshadesolutions.co.za" target="_blank" style="color:#67a8ff;text-decoration:none;">eliteshadesolutions.co.za</a><br/>
                <a href="https://eliteshadesolutions.co.za/quote" target="_blank" class="footer-button" style="display:inline-block;margin-top:6px;padding:8px 13px;background:#1769e0;border-radius:6px;color:#ffffff;text-decoration:none;font-weight:800;">Get an instant estimate →</a>
              </td>
            </tr>
          </table>
          <p style="margin:20px 0 0;padding-top:14px;border-top:1px solid #31435d;font-size:9px;line-height:1.55;color:#71839a;">This message was sent by Elite Shade Solutions regarding an enquiry, quote, invoice or project update. If it reached you in error, please reply and let us know.</p>
        </td>
      </tr>

    </table>
  </td></tr>
</table>
</body>
</html>`}(b,e,m,l,{salesName:j.settings.sales_name||"Jean-Pierre Miller",salesPhone:o,marketingName:j.settings.marketing_name||"Michael Theron",marketingPhone:j.settings.marketing_phone||"060 949 1197",salesEmail:j.settings.sales_email||l,infoEmail:j.settings.info_email||"info@eliteshadesolutions.co.za"},i),q=f("ELITE_SMTP_HOST")||j.settings.smtp_host||"",r=h("ELITE_SMTP_PORT")||j.settings.smtp_port||587,s=f("ELITE_SMTP_USER")||j.settings.smtp_user||"",t=f("ELITE_SMTP_PASS")||j.settings.smtp_pass||"",u=g("ELITE_SMTP_SECURE")??!!j.settings.smtp_secure,v=f("ELITE_EMAIL_PROVIDER"),w="smtp"===v||"resend"===v||"outbox"===v?v:j.settings.email_provider||(k?"resend":"outbox"),x="outbox",y="queued";if("smtp"===w&&q&&s)try{let d=(await c.e(5112).then(c.t.bind(c,52731,19))).createTransport({host:q,port:r,secure:u,auth:{user:s,pass:t}});await d.sendMail({from:`${m} <${l}>`,to:a,subject:b,text:e,html:p}),x="smtp",y="sent"}catch{x="smtp",y="failed"}else if("resend"===w&&k)try{let c=await fetch("https://api.resend.com/emails",{method:"POST",headers:{Authorization:`Bearer ${k}`,"Content-Type":"application/json"},body:JSON.stringify({from:`${m} <${l}>`,to:a,subject:b,text:e,html:p})});x="resend",y=c.ok?"sent":"failed"}catch{x="resend",y="failed"}return(0,d.Tk)(c=>{let f={id:(0,d.Ld)("eml_"),to:a,subject:b,body:e,html:p,sent_at:new Date().toISOString(),channel:x,status:y};return c.emails.unshift(f),f})}async function j(a,b,e,i={}){let k=await (0,d.xA)(),l=f("ELITE_RESEND_API_KEY")||k.settings.resend_api_key?.trim(),m=i.from?.trim()||"sales@eliteshadesolutions.co.za",n=i.replyTo?.trim()||m,o=k.settings.company_name||"Elite Shade Solutions",p=f("ELITE_SMTP_HOST")||k.settings.smtp_host||"",q=h("ELITE_SMTP_PORT")||k.settings.smtp_port||587,r=f("ELITE_SMTP_USER")||k.settings.smtp_user||"",s=f("ELITE_SMTP_PASS")||k.settings.smtp_pass||"",t=g("ELITE_SMTP_SECURE")??!!k.settings.smtp_secure,u=f("ELITE_EMAIL_PROVIDER"),v="smtp"===u||"resend"===u||"outbox"===u?u:k.settings.email_provider||(l?"resend":"outbox"),w=e.replace(/<style[\s\S]*?<\/style>/gi," ").replace(/<script[\s\S]*?<\/script>/gi," ").replace(/<[^>]+>/g," ").replace(/&nbsp;/gi," ").replace(/&amp;/gi,"&").replace(/\s+/g," ").trim(),x="outbox",y="queued",z="";if("smtp"===v&&p&&r)try{let d=(await c.e(5112).then(c.t.bind(c,52731,19))).createTransport({host:p,port:q,secure:t,auth:{user:r,pass:s}});await d.sendMail({from:`${o} <${m}>`,replyTo:n,to:a,subject:b,text:w,html:e}),x="smtp",y="sent"}catch(a){x="smtp",y="failed",z=a instanceof Error?a.message:"SMTP delivery failed"}else if("resend"===v&&l)try{let c=await fetch("https://api.resend.com/emails",{method:"POST",headers:{Authorization:`Bearer ${l}`,"Content-Type":"application/json"},body:JSON.stringify({from:`${o} <${m}>`,reply_to:n,to:a,subject:b,text:w,html:e})});x="resend",y=c.ok?"sent":"failed",c.ok||(z=`Email provider returned ${c.status}`)}catch(a){x="resend",y="failed",z=a instanceof Error?a.message:"Email delivery failed"}return(0,d.Tk)(c=>{let f={id:(0,d.Ld)("eml_"),to:a,subject:b,body:w,html:e,sent_at:new Date().toISOString(),channel:x,status:y,...z?{error:z}:{}};return c.emails.unshift(f),f})}},96487:()=>{}};