module.exports=[28496,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_activity_route_actions_20tc28b2f6hkh.js.map