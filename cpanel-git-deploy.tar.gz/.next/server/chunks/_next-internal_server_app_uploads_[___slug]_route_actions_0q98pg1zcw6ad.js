module.exports=[89508,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_uploads_%5B___slug%5D_route_actions_0q98pg1zcw6ad.js.map