module.exports=[39720,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_settings_test-email_route_actions_0y4iv-0icqnle.js.map