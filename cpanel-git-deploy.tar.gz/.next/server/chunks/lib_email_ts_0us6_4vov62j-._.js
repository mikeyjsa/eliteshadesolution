module.exports=[133,e=>{"use strict";var t=e.i(62294),a=e.i(22734);function i(e){return process.env[e]?.trim()||""}function s(e){let t=process.env[e]?.trim().toLowerCase();if(t)return"1"===t||"true"===t||"yes"===t||"on"===t}function n(e){let t=process.env[e]?.trim();if(!t)return;let a=Number(t);return Number.isFinite(a)?a:void 0}async function o(a,o,r,l){let p=await (0,t.f)(),d=i("ELITE_RESEND_API_KEY")||p.settings.resend_api_key?.trim(),c=i("ELITE_EMAIL_FROM")||p.settings.email_from||"sales@eliteshadesolutions.co.za",m=p.settings.company_name||"Elite Shade Solutions",g=p.settings.sales_phone?.trim()||"",f=g&&"0676182422"!==g.replace(/\D/g,"")?g:"071 581 4268",h=function(e,t,a="Elite Shade Solutions",i="sales@eliteshadesolutions.co.za",s,n){let o=s??{salesName:"Jean-Pierre Miller",salesPhone:"071 581 4268",marketingName:"Michael Theron",marketingPhone:"060 949 1197",salesEmail:"sales@eliteshadesolutions.co.za",infoEmail:"info@eliteshadesolutions.co.za"},r=`+${o.salesPhone.replace(/\D/g,"").replace(/^0/,"27")}`,l=`+${o.marketingPhone.replace(/\D/g,"").replace(/^0/,"27")}`,p=i.trim().toLowerCase()===o.infoEmail.trim().toLowerCase(),d=p?o.marketingName:o.salesName,c=p?o.marketingPhone:o.salesPhone,m=p?l:r,g=p?o.infoEmail:o.salesEmail;return`<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>${e}</title>
<style>
  body { margin: 0 !important; padding: 0 !important; width: 100% !important; -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; }
  table, td { border-collapse: collapse; mso-table-lspace: 0; mso-table-rspace: 0; }
  img { border: 0; outline: none; text-decoration: none; -ms-interpolation-mode: bicubic; }
  @media only screen and (max-width: 620px) {
    .email-wrap { padding: 12px 0 !important; }
    .email-card { width: 100% !important; max-width: 100% !important; border-radius: 0 !important; }
    .email-pad { padding-left: 22px !important; padding-right: 22px !important; }
    .footer-stack { display: block !important; width: 100% !important; max-width: 100% !important; text-align: left !important; }
    .footer-spacer { display: none !important; width: 0 !important; height: 0 !important; }
    .footer-details { padding-top: 18px !important; }
    .footer-actions { padding-top: 14px !important; text-align: left !important; }
    .footer-button { display: block !important; text-align: center !important; }
  }
</style>
</head>
<body style="margin:0;padding:0;background:#e8ecef;font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" class="email-wrap" style="background:#e8ecef;padding:32px 16px;">
  <tr><td align="center">
    <table role="presentation" width="600" cellpadding="0" cellspacing="0" class="email-card" style="max-width:600px;width:100%;background:#ffffff;border-radius:16px;overflow:hidden;box-shadow:0 8px 32px rgba(28,39,51,0.12);">

      <!-- HEADER -->
      <tr>
        <td style="background:#1c2733;padding:28px 36px 20px;text-align:left;">
          <div style="font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;font-size:22px;font-weight:800;letter-spacing:0.08em;text-transform:uppercase;color:#ffffff;">ELITE SHADE</div>
          <div style="font-size:11px;font-weight:700;letter-spacing:0.22em;text-transform:uppercase;color:#c9a24b;margin-top:4px;">Engineered Shade. Exceptional Spaces.</div>
          <div style="height:3px;background:linear-gradient(90deg,#c9a24b,transparent);margin-top:18px;border-radius:2px;"></div>
        </td>
      </tr>

      <!-- SUBJECT BAND -->
      <tr>
        <td style="background:#283746;padding:14px 36px;">
          <p style="margin:0;font-size:16px;font-weight:700;color:#ffffff;letter-spacing:-0.01em;">${e}</p>
        </td>
      </tr>

      <!-- BODY -->
      <tr>
        <td class="email-pad" style="padding:36px 36px 28px;">
          ${t.split("\n").map(e=>e.trim()?`<p style="margin:0 0 16px;font-size:15px;line-height:1.7;color:#22303c;">${e}</p>`:"<br/>").join("")}
          ${n?`
          <table role="presentation" cellpadding="0" cellspacing="0" style="margin:8px 0 4px;">
            <tr>
              <td style="background:#c9a24b;border-radius:10px;">
                <a href="${n.url}" target="_blank" style="display:inline-block;padding:14px 30px;font-size:15px;font-weight:800;color:#1c2733;text-decoration:none;letter-spacing:0.02em;">${n.label} →</a>
              </td>
            </tr>
          </table>
          <p style="margin:10px 0 0;font-size:12px;color:#5b6b7a;">Or copy this link into your browser:<br/><a href="${n.url}" style="color:#c9a24b;word-break:break-all;">${n.url}</a></p>
          `:""}
        </td>
      </tr>

      <!-- CTA STRIP -->
      <tr>
        <td class="email-pad" style="padding:0 36px 32px;">
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#eef5ff;border-left:4px solid #1769e0;border-radius:10px;padding:0;">
            <tr>
              <td style="padding:20px 24px;">
                <p style="margin:0 0 8px;font-size:13px;font-weight:800;letter-spacing:0.06em;text-transform:uppercase;color:#1769e0;">Questions about your shade project?</p>
                <p style="margin:0;font-size:14px;color:#283746;line-height:1.65;">Reply to this email or call <a href="tel:${m}" style="color:#1769e0;text-decoration:none;font-weight:800;">${d} on ${c}</a>. We are ready to help with measurements, materials, quotes and installation planning.</p>
              </td>
            </tr>
          </table>
        </td>
      </tr>

      <!-- FOOTER -->
      <tr>
        <td class="email-pad" style="background:#10213d;padding:28px 36px 22px;">
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
            <tr>
              <td class="footer-stack" width="185" valign="top" style="width:185px;">
                <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:10px;">
                  <tr>
                    <td style="padding:14px 12px;">
                      <a href="https://eliteshadesolutions.co.za" target="_blank" style="text-decoration:none;">
                        <img src="https://eliteshadesolutions.co.za/_next/image?url=%2Flogo.png&amp;w=640&amp;q=75" width="160" alt="Elite Shade Solutions" style="display:block;width:160px;max-width:100%;height:auto;" />
                      </a>
                    </td>
                  </tr>
                </table>
              </td>
              <td class="footer-spacer" width="22" style="width:22px;">&nbsp;</td>
              <td class="footer-stack footer-details" valign="top" style="font-size:12px;color:#b9c7d8;line-height:1.7;">
                <strong style="font-size:14px;color:#ffffff;">${a}</strong><br/>
                <span style="color:#67a8ff;font-size:10px;font-weight:800;letter-spacing:0.1em;text-transform:uppercase;">Engineered shade. Exceptional spaces.</span><br/>
                Cape Town, Western Cape
              </td>
            </tr>
          </table>
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin-top:20px;border-top:1px solid #31435d;">
            <tr>
              <td class="footer-stack" valign="top" style="padding-top:17px;font-size:11px;color:#b9c7d8;line-height:1.8;">
                <strong style="color:#ffffff;">${d}</strong> \xb7 ${p?"Marketing / Online Sales":"Sales"}<br/>
                <a href="tel:${m}" style="color:#ffffff;text-decoration:none;font-weight:700;">${c}</a><br/>
                <a href="mailto:${g}" style="color:#67a8ff;text-decoration:none;">${g}</a>
              </td>
              <td class="footer-stack footer-actions" align="right" valign="top" style="padding-top:17px;font-size:11px;line-height:1.8;">
                <a href="https://eliteshadesolutions.co.za" target="_blank" style="color:#67a8ff;text-decoration:none;">eliteshadesolutions.co.za</a><br/>
                <a href="https://eliteshadesolutions.co.za/quote" target="_blank" class="footer-button" style="display:inline-block;margin-top:6px;padding:8px 13px;background:#1769e0;border-radius:6px;color:#ffffff;text-decoration:none;font-weight:800;">Get an instant estimate →</a>
              </td>
            </tr>
          </table>
          <p style="margin:20px 0 0;padding-top:14px;border-top:1px solid #31435d;font-size:9px;line-height:1.55;color:#71839a;">This message was sent by Elite Shade Solutions regarding an enquiry, quote, invoice or project update. If it reached you in error, please reply and let us know.</p>
        </td>
      </tr>

    </table>
  </td></tr>
</table>
</body>
</html>`}(o,r,m,c,{salesName:p.settings.sales_name||"Jean-Pierre Miller",salesPhone:f,marketingName:p.settings.marketing_name||"Michael Theron",marketingPhone:p.settings.marketing_phone||"060 949 1197",salesEmail:p.settings.sales_email||c,infoEmail:p.settings.info_email||"info@eliteshadesolutions.co.za"},l),u=i("ELITE_SMTP_HOST")||p.settings.smtp_host||"",x=n("ELITE_SMTP_PORT")||p.settings.smtp_port||587,b=i("ELITE_SMTP_USER")||p.settings.smtp_user||"",y=i("ELITE_SMTP_PASS")||p.settings.smtp_pass||"",E=s("ELITE_SMTP_SECURE")??!!p.settings.smtp_secure,_=i("ELITE_EMAIL_PROVIDER"),w="smtp"===_||"resend"===_||"outbox"===_?_:p.settings.email_provider||(d?"resend":"outbox"),S="outbox",T="queued";if("smtp"===w&&u&&b)try{let t=(await e.A(57424)).createTransport({host:u,port:x,secure:E,auth:{user:b,pass:y}});await t.sendMail({from:`${m} <${c}>`,to:a,subject:o,text:r,html:h}),S="smtp",T="sent"}catch{S="smtp",T="failed"}else if("resend"===w&&d)try{let e=await fetch("https://api.resend.com/emails",{method:"POST",headers:{Authorization:`Bearer ${d}`,"Content-Type":"application/json"},body:JSON.stringify({from:`${m} <${c}>`,to:a,subject:o,text:r,html:h})});S="resend",T=e.ok?"sent":"failed"}catch{S="resend",T="failed"}return(0,t.R)(e=>{let i={id:(0,t.e)("eml_"),to:a,subject:o,body:r,html:h,sent_at:new Date().toISOString(),channel:S,status:T};return e.emails.unshift(i),i})}async function r(o,l,p,d={}){let c=await (0,t.f)(),m=i("ELITE_RESEND_API_KEY")||c.settings.resend_api_key?.trim(),g=d.from?.trim()||"sales@eliteshadesolutions.co.za",f=d.replyTo?.trim()||g,h=c.settings.company_name||"Elite Shade Solutions",u=i("ELITE_SMTP_HOST")||c.settings.smtp_host||"",x=n("ELITE_SMTP_PORT")||c.settings.smtp_port||587,b=i("ELITE_SMTP_USER")||c.settings.smtp_user||"",y=i("ELITE_SMTP_PASS")||c.settings.smtp_pass||"",E=s("ELITE_SMTP_SECURE")??!!c.settings.smtp_secure,_=i("ELITE_EMAIL_PROVIDER"),w="smtp"===_||"resend"===_||"outbox"===_?_:c.settings.email_provider||(m?"resend":"outbox"),S=p.replace(/<style[\s\S]*?<\/style>/gi," ").replace(/<script[\s\S]*?<\/script>/gi," ").replace(/<[^>]+>/g," ").replace(/&nbsp;/gi," ").replace(/&amp;/gi,"&").replace(/\s+/g," ").trim(),T=d.attachment,k="outbox",P="queued",$="";if("smtp"===w&&u&&b)try{let t=(await e.A(57424)).createTransport({host:u,port:x,secure:E,auth:{user:b,pass:y}});await t.sendMail({from:`${h} <${g}>`,replyTo:f,to:o,subject:l,text:S,html:p,attachments:T?[{filename:T.filename,path:T.path,contentType:"application/pdf"}]:void 0}),k="smtp",P="sent"}catch(e){k="smtp",P="failed",$=e instanceof Error?e.message:"SMTP delivery failed"}else if("resend"===w&&m)try{let e=T?[{filename:T.filename,content:(await a.promises.readFile(T.path)).toString("base64")}]:void 0,t=await fetch("https://api.resend.com/emails",{method:"POST",headers:{Authorization:`Bearer ${m}`,"Content-Type":"application/json"},body:JSON.stringify({from:`${h} <${g}>`,reply_to:f,to:o,subject:l,text:S,html:p,attachments:e})});k="resend",P=t.ok?"sent":"failed",t.ok||($=`Email provider returned ${t.status}`)}catch(e){k="resend",P="failed",$=e instanceof Error?e.message:"Email delivery failed"}return(0,t.R)(e=>{let a={id:(0,t.e)("eml_"),to:o,subject:l,body:S,html:p,sent_at:new Date().toISOString(),channel:k,status:P,...$?{error:$}:{}};return e.emails.unshift(a),a})}e.s(["a",0,function(e,t){return e.replace(/\{\{(\w+)\}\}/g,(e,a)=>t[a]??"")},"R",0,o,"X",0,r])}];

//# sourceMappingURL=lib_email_ts_0us6_4vov62j-._.js.map