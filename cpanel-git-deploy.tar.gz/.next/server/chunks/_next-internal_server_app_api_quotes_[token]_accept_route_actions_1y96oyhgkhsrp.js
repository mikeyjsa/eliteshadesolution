module.exports=[84375,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_quotes_%5Btoken%5D_accept_route_actions_1y96oyhgkhsrp.js.map