module.exports=[6743,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_leads_archive_route_actions_07-0rwqav0jcx.js.map