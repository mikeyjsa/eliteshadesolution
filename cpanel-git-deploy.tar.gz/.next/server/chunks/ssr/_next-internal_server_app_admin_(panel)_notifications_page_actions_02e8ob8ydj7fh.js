module.exports=[25942,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_%28panel%29_notifications_page_actions_02e8ob8ydj7fh.js.map