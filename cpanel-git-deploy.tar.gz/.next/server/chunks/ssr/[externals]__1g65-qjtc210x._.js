module.exports=[21517,(a,b,c)=>{b.exports=a.x("http",()=>require("http"))},24836,(a,b,c)=>{b.exports=a.x("https",()=>require("https"))},4446,(a,b,c)=>{b.exports=a.x("net",()=>require("net"))},55004,(a,b,c)=>{b.exports=a.x("tls",()=>require("tls"))},92509,(a,b,c)=>{b.exports=a.x("url",()=>require("url"))}];

//# sourceMappingURL=%5Bexternals%5D__1g65-qjtc210x._.js.map