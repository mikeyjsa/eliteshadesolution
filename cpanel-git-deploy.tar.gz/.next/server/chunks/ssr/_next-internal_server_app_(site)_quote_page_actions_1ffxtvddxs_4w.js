module.exports=[24212,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28site%29_quote_page_actions_1ffxtvddxs_4w.js.map