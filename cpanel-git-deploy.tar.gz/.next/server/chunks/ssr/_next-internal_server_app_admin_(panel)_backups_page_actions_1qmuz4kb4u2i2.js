module.exports=[52804,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_%28panel%29_backups_page_actions_1qmuz4kb4u2i2.js.map