module.exports=[21114,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_%28panel%29_leads_page_actions_1u56370ua9w1g.js.map