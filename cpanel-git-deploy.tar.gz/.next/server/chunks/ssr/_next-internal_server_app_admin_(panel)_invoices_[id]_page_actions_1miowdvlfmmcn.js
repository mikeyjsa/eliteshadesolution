module.exports=[30678,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_%28panel%29_invoices_%5Bid%5D_page_actions_1miowdvlfmmcn.js.map