module.exports=[99793,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_%28panel%29_invoices_page_actions_0628ijiwxw3q5.js.map