module.exports=[70586,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_%28panel%29_content_page_actions_1tsjw_07n16n0.js.map