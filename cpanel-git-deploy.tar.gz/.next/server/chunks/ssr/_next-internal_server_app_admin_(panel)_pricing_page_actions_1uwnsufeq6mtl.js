module.exports=[50479,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_%28panel%29_pricing_page_actions_1uwnsufeq6mtl.js.map