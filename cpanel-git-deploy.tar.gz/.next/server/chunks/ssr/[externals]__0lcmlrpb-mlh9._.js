module.exports=[874,(a,b,c)=>{b.exports=a.x("buffer",()=>require("buffer"))},2157,(a,b,c)=>{b.exports=a.x("node:fs",()=>require("node:fs"))},50227,(a,b,c)=>{b.exports=a.x("node:path",()=>require("node:path"))}];

//# sourceMappingURL=%5Bexternals%5D__0lcmlrpb-mlh9._.js.map