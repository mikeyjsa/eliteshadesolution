module.exports=[81926,a=>{"use strict";a.s(["G",0,function(a){return new Date(a).toLocaleDateString("en-ZA",{day:"2-digit",month:"short",year:"numeric"})},"I",0,function(a){return"R "+Math.round(a).toLocaleString("en-ZA")}])}];

//# sourceMappingURL=lib_format_ts_0ppb46pgpvw6z._.js.map