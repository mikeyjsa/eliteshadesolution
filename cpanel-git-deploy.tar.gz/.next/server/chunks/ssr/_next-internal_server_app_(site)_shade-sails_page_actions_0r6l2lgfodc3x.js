module.exports=[49179,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28site%29_shade-sails_page_actions_0r6l2lgfodc3x.js.map