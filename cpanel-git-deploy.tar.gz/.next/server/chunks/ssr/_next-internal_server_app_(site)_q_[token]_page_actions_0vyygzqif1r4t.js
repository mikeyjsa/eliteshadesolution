module.exports=[37610,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28site%29_q_%5Btoken%5D_page_actions_0vyygzqif1r4t.js.map