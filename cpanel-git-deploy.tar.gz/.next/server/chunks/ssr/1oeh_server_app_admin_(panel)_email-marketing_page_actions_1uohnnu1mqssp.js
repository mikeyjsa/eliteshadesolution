module.exports=[15793,(a,b,c)=>{}];

//# sourceMappingURL=1oeh_server_app_admin_%28panel%29_email-marketing_page_actions_1uohnnu1mqssp.js.map