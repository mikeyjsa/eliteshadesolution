module.exports=[58161,a=>{"use strict";function b(a){}a.s(["I",0,function(a,c){b(b=>b("event",a,c??{}))},"x",0,function(a,c){b(b=>b("event","page_view",{page_path:c,page_location:c,page_title:"u">typeof document?document.title:c,send_to:a}))}])}];

//# sourceMappingURL=lib_gtag_ts_14wlsspyopuyz._.js.map