module.exports=[9483,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_%28panel%29_reports_page_actions_1l0kkgglqpfj4.js.map