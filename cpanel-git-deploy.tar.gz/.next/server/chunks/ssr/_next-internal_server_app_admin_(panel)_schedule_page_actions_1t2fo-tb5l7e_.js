module.exports=[25116,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_%28panel%29_schedule_page_actions_1t2fo-tb5l7e_.js.map