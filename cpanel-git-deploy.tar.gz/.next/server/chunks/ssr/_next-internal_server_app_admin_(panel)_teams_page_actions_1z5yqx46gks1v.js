module.exports=[86310,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_%28panel%29_teams_page_actions_1z5yqx46gks1v.js.map