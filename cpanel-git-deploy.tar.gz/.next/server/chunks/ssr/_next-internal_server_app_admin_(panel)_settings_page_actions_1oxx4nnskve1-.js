module.exports=[69170,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_%28panel%29_settings_page_actions_1oxx4nnskve1-.js.map