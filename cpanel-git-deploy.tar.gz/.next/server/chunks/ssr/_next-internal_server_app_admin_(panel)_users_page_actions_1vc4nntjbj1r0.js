module.exports=[38731,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_%28panel%29_users_page_actions_1vc4nntjbj1r0.js.map