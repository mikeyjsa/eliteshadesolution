module.exports=[98812,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_invoices_%5Bid%5D_pdf_route_actions_1h1e9g55lgc5a.js.map