module.exports=[5475,e=>{"use strict";var t=e.i(54799),i=e.i(62294),o=e.i(133),a=e.i(7745),n=e.i(56158),s=e.i(9294);async function u(e){return(0,i.R)(i=>{let o=i.quotes.find(t=>t.id===e);return o?(o.public_token||(o.public_token=(0,t.randomBytes)(18).toString("hex")),o.public_token):null})}function r(e){return(0,s._)(`/q/${e}`)}async function l(e){let t=await (0,i.f)(),u=t.customers.find(t=>t.id===e.customer_id);if(!u||!e.public_token||null==e.final_total)return;let l=r(e.public_token),c=(0,a.I)(e.final_total),d=(0,a.I)(Math.round(e.final_total*t.settings.deposit_pct/100)),m=(0,s.T)(t.settings),y=(0,s.b)({settings:t.settings,users:t.users}),p=`Hi ${u.name},

Good news — your Elite Shade quote ${(0,n.N)(e)} is confirmed at ${c} (excl VAT).

View the full breakdown, download your quote as a PDF, and accept it online at the link below. Once you accept, we'll email your ${t.settings.deposit_pct}% deposit invoice (${d}) with secure payment options — ${m}.

Your quote is valid for 14 days. Nothing is booked until you accept, and the final scope is always confirmed at your free site survey.`;for(let t of(await (0,o.R)(u.email,`Your quote ${(0,n.N)(e)} is ready — ${c}`,p,{label:"View & accept my quote",url:l}),y))await (0,o.R)(t,`Quote ready — ${(0,n.N)(e)} for ${u.name}`,`Quote ${(0,n.N)(e)} has been confirmed and emailed to ${u.email}.

Client: ${u.name}
Total: ${c}
Deposit: ${d}
View link: ${l}
CRM: ${(0,s._)(`/admin/quotes/${e.id}`)}`);await (0,i.R)(t=>{t.activities.unshift({id:(0,i.e)("act_"),quote_id:e.id,user:"system",user_id:"system",type:"email",message:`Quote ${(0,n.N)(e)} emailed to ${u.email} with view/accept link.`,created_at:new Date().toISOString()})})}async function c(e,t){let u=await (0,i.f)(),r=u.customers.find(t=>t.id===e.customer_id);if(!r)return;let l=(0,s.c)(u.settings),c=(0,s._)(`/pay/${t.id}`),d=(0,s._)(`/api/invoices/${t.id}/pdf`),m=(0,s.q)(u.settings),y=(0,s.b)({settings:u.settings,users:u.users}),p=[`Hi ${r.name},`,"",`Thank you for accepting quote ${(0,n.N)(e)}. Your ${u.settings.deposit_pct}% deposit invoice ${t.number} for ${(0,a.I)(t.amount)} is attached below as a download link.`,"",`Download your invoice: ${d}`,"",l?"You can pay in whichever way suits you:":"Please pay by EFT to:","",...l?["1. PayFast (card / instant EFT) — use the secure payment button below.","","2. Direct EFT — pay to:"]:[],...m.split("\n"),`Reference: ${t.number}`,"","As soon as your deposit reflects, we confirm your installation date by email. If you pay by EFT, simply reply with your proof of payment to speed things up."].join("\n");for(let e of(await (0,o.R)(r.email,`Deposit invoice ${t.number} — secure your install date`,p,{label:l?`Pay ${(0,a.I)(t.amount)} deposit securely`:"View payment instructions",url:c}),y))await (0,o.R)(e,`Deposit invoice sent — ${t.number}`,`Deposit invoice ${t.number} has been sent to ${r.email}.

Client: ${r.name}
Amount: ${(0,a.I)(t.amount)}
Payment mode: ${l?"Gateway + EFT":"EFT only"}
Pay page: ${c}
CRM: ${(0,s._)(`/admin/invoices/${t.id}`)}`);await (0,i.R)(o=>{o.activities.unshift({id:(0,i.e)("act_"),quote_id:e.id,user:"system",user_id:"system",type:"email",message:`Deposit invoice ${t.number} emailed to ${r.email} with ${l?"PayFast + EFT":"EFT-only"} payment options.`,created_at:new Date().toISOString()})})}e.s(["r",0,u,"$",0,r,"K",0,c,"A",0,l])}];

//# sourceMappingURL=lib_quote-flow_ts_0h6q9yri965_s._.js.map