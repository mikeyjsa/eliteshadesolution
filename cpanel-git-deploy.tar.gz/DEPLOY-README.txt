Elite Shade Solutions cPanel deploy bundle

Upload and extract this bundle into the live Node.js application root.
Expected cPanel startup file: server.js
Expected persistent runtime folder in the live root: .data/

This bundle contains:
- Next.js standalone server output
- .next/static assets
- public assets

This bundle intentionally does not include .data/ so live data is preserved.